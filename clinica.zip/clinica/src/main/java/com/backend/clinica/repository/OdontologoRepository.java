package com.backend.clinica.repository;
import com.backend.clinica.entity.Odontologo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OdontologoRepository extends JpaRepository<Odontologo, Long> {
    Odontologo findByMatriculaAndNombre(String matricula, String nombre);
}

