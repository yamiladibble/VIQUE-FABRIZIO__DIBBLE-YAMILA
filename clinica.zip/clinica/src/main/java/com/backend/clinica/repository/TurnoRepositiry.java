package com.backend.clinica.repository;

import com.backend.clinica.entity.Turno;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;

public interface TurnoRepositiry extends JpaRepositoryImplementation<Turno, Long> {
}
